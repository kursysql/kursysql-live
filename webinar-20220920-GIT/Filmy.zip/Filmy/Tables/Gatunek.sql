CREATE TABLE [dbo].[Gatunek] (
    [GatunekID] INT        IDENTITY (1, 1) NOT NULL,
    [Gatunek]   CHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([GatunekID] ASC)
);


GO

