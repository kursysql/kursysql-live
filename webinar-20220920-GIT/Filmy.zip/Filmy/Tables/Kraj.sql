CREATE TABLE [dbo].[Kraj] (
    [KrajID] INT            IDENTITY (1, 1) NOT NULL,
    [Kraj]   NVARCHAR (100) NOT NULL,
    PRIMARY KEY CLUSTERED ([KrajID] ASC)
);


GO

